package com.example.auctabackendapp.repositories;

import com.example.auctabackendapp.model.Review;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;


public interface ReviewRepository extends JpaRepository<Review,Integer> {
    List<Review> findByMovieID(int movieID);
    Review findById(int id);

    List<Review> findByRating(int rating);

    @Query(value = "select r.id,r.movie_id,r.rating,r.review\n" +
            "from review as r inner join average_rating as avgr\n" +
            "on r.movie_id=avgr.movieid order by avgr.averagerating desc ;",
            nativeQuery = true)
    List<Review> sortedReviewList();

}
