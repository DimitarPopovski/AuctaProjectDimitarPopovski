package com.example.auctabackendapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuctaBackEndAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
