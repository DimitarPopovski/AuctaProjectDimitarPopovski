package com.example.auctabackendapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.auctabackendapp.model.AverageRating;
import com.example.auctabackendapp.repositories.AverageRatingRepository;

import java.util.List;
@CrossOrigin(origins= {"*"}, maxAge = 6400, allowCredentials = "false" )
@RestController
public class AverageRatingController {
    @Autowired
    AverageRatingRepository averageRatingRepository;

    @RequestMapping("/allavgratings")
    public List<AverageRating> allAvgRatings(){ return averageRatingRepository.findAll();}

}
