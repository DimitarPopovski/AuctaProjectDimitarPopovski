package com.example.auctabackendapp.model;

import jakarta.persistence.*;

import java.math.BigDecimal;

@Entity
@Table(name = "AverageRating")
public class AverageRating {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "movieID")
    private int movieID;

    @Column(name = "averagerating")
    private BigDecimal averagerating;

    public AverageRating(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setAveragerating(BigDecimal averagerating) {
        this.averagerating = averagerating;
    }

    public BigDecimal getAveragerating() {
        return averagerating;
    }

    public int getMovieID() {
        return movieID;
    }

    public void setMovieID(int movieID) {
        this.movieID = movieID;
    }
}
