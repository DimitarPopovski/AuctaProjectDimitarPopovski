package com.example.auctabackendapp.controller;

import com.example.auctabackendapp.model.AverageRating;
import com.example.auctabackendapp.model.Movies;
import com.example.auctabackendapp.model.Review;
import com.example.auctabackendapp.repositories.AverageRatingRepository;
import com.example.auctabackendapp.repositories.MoviesRepository;
import com.example.auctabackendapp.repositories.ReviewRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

@CrossOrigin(origins= {"*"}, maxAge = 6400, allowCredentials = "false" )
@RestController
public class ReviewController {
    @Autowired
    ReviewRepository reviewRepository;
    @Autowired
    AverageRatingRepository averageRatingRepository;
    @Autowired
    MoviesRepository moviesRepository;

    @CrossOrigin(origins= {"*"}, maxAge = 6400, allowCredentials = "false" )
    @PostMapping("/createReview/{movieID}/{review}/{rating}")
    public void addReview(@PathVariable int movieID, @PathVariable String review,@PathVariable int rating){
        Review newReview = new Review();
        newReview.setMovieID(movieID);
        newReview.setReview(review);
        newReview.setRating(rating);

        reviewRepository.save(newReview);
    }

    @RequestMapping("/reviews")
    public List<Review> allReviews(){
        return reviewRepository.findAll();
    }

    @PostMapping("/saveavgrating/{movieID}/")
    public void calcAvgRating(@PathVariable int movieID){
        List<Review> ratings=reviewRepository.findByMovieID(movieID);
        int sumr = 0;
        int numreviews=0;
        for (Review rating : ratings) {
            if (rating.getMovieID() == movieID) {
                sumr += rating.getRating();
                numreviews += 1;
            }
        }
        double globalrating = (double) sumr/numreviews;
        BigDecimal bd = new BigDecimal(globalrating).setScale(2, RoundingMode.HALF_UP);
        AverageRating avg= averageRatingRepository.findByMovieID(movieID);
        if(avg!=null){
            avg.setAveragerating(bd);
            averageRatingRepository.save(avg);
        }
        else {
            AverageRating averageRating= new AverageRating();
            averageRating.setMovieID(movieID);
            averageRating.setAveragerating(bd);
            averageRatingRepository.save(averageRating);
        }
    }

    @CrossOrigin(origins= {"*"}, maxAge = 6400, allowCredentials = "false" )
    @RequestMapping("/reviewsByID/{movieID}")
    public List<Review> filterByMovieID(@PathVariable int movieID){
        return reviewRepository.findByMovieID(movieID);
    }

    @CrossOrigin(origins= {"*"}, maxAge = 6400, allowCredentials = "false" )
    @RequestMapping("/reviewsByRating/{rating}")
    public List<Review> filterByRating(@PathVariable int rating){
        return reviewRepository.findByRating(rating);
    }

    @CrossOrigin(origins= {"*"}, maxAge = 6400, allowCredentials = "false" )
    @RequestMapping("/reviewsByTitle/{title}")
    public List<Review> filterByMovieTitle(@PathVariable String title){
        Movies movie= moviesRepository.findByMovie(title);
        int movieID = movie.getId();
        return reviewRepository.findByMovieID(movieID);
    }

    @CrossOrigin(origins= {"*"}, maxAge = 6400, allowCredentials = "false" )
    @RequestMapping("/reviewsByAvgRating/{avgrating}")
    public List<Review> filterByAvgRating(@PathVariable BigDecimal avgrating){
        List<Integer> movieIDs = new ArrayList<>();
        List<AverageRating> avgr= averageRatingRepository.findByaveragerating(avgrating);
        List<Review> allreviews = reviewRepository.findAll();
        List<Review> filteredReviews = new ArrayList<>();
        for(AverageRating rating : avgr){
            movieIDs.add(rating.getMovieID());
        }
        for (int id : movieIDs) {
            for (Review r : allreviews) {
                if(r.getMovieID()==id) {
                    filteredReviews.add(r);
                }
            }
        }
        return filteredReviews;
    }

    @RequestMapping("/allreviewssorted")
    public List<Review> allReviewsSorted(){
        List<Review> sortedreviews=reviewRepository.sortedReviewList();
        return sortedreviews;
    }
}
