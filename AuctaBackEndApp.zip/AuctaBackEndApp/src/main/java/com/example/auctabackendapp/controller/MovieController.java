package com.example.auctabackendapp.controller;

import com.example.auctabackendapp.model.Movies;
import com.example.auctabackendapp.model.Review;
import com.example.auctabackendapp.repositories.ReviewRepository;
import com.example.auctabackendapp.repositories.MoviesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin(origins= {"*"}, maxAge = 6400, allowCredentials = "false" )
@RestController
public class MovieController {
    @Autowired
    MoviesRepository moviesRepository;
    @Autowired
    ReviewRepository reviewRepository;

    @RequestMapping("/movies")
    public List<Movies> allMovies(){
        return moviesRepository.findAll();
    }

    @PostMapping("/filterbyt/{title}")
    public List<Movies> movieByTitle(@PathVariable String title){
        return moviesRepository.findByTitle(title);
    }

    @PostMapping("/filterbyg/{genre}")
    public List<Movies> movieByGenre(@PathVariable String genre){
        List<Movies> movies = moviesRepository.findAll();
        String []genres=genre.split(",");
        List<Movies> filteredList = new ArrayList<Movies>();
//        for(String g: genres) {
//            for (Movies movie : movies) {
//                if (movie.getGenre().contains(g)){
//                    if(!filteredList.contains(movie)) {
//                        filteredList.add(movie);
//                    }
//                }
//            }
//        }
//        return filteredList;
        List<String> genreList = Arrays.asList(genres);

        filteredList= movies.stream()
                .filter(movie -> genreList.stream().allMatch(movie.getGenre()::contains))
                .collect(Collectors.toList());
        return filteredList;
    }

    @PostMapping("/filterbyy/{year}")
    public List<Movies> movieByYear(@PathVariable int year){
        return moviesRepository.findByYear(year);
    }

    @CrossOrigin(origins= {"*"}, maxAge = 6400, allowCredentials = "false" )
    @PostMapping("/movies/{yearFrom}/{yearTo}")
    public List<Movies> movieByRange(@PathVariable int yearFrom, @PathVariable int yearTo){
        return moviesRepository.findByRange(yearFrom,yearTo);
    }
//    @RequestMapping("/movies/{genres}")
//    public List<Movies> movieByMultipleGenres(@PathVariable List<String> genres){
//        return moviesRepository.findByGenres(genres);
//    }

    @RequestMapping("/createmovie/{title}/{genre}/{description}/{year}")
    public void addMovie(@PathVariable String title, @PathVariable String genre,@PathVariable String description, @PathVariable int year){
        Movies newMovie = new Movies();
        newMovie.setDescription(description);
        newMovie.setGenre(genre);
        newMovie.setYear(year);
        newMovie.setTitle(title);
        moviesRepository.save(newMovie);
    }

    @RequestMapping("/movie/{id}")
    public List<Movies> getSpecificMovie(@PathVariable int id){
        List<Movies> movie = moviesRepository.findById(id);
        return movie;
    }

    @RequestMapping("/allmoviessorted")
    public List<Movies> allMoviesSorted(){
        List<Movies> sortedmovies=moviesRepository.sortedMovieList();
        return sortedmovies;
    }

}
