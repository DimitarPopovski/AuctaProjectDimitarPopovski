package com.example.auctabackendapp.repositories;

import com.example.auctabackendapp.model.AverageRating;
import org.springframework.data.jpa.repository.JpaRepository;

import java.math.BigDecimal;
import java.util.List;

public interface AverageRatingRepository extends JpaRepository<AverageRating,Integer> {

    AverageRating findByMovieID(int movieID);

    List<AverageRating> findByaveragerating(BigDecimal averagerating);
}
