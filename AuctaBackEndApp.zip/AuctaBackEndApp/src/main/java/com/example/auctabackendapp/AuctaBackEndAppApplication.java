package com.example.auctabackendapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuctaBackEndAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(AuctaBackEndAppApplication.class, args);
    }

}
