package com.example.auctabackendapp.repositories;

import com.example.auctabackendapp.model.Movies;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;


public interface MoviesRepository extends JpaRepository<Movies, Integer>{
    List<Movies> findByTitle(String title);
    List<Movies> findById(int id);
    List<Movies> findByYear(int year);

    @Query(
            value= "select m.id,m.description,m.genre,m.title, m.year \n" +
                    "from movies as m \n" +
                    "where m.title = :title",
            nativeQuery = true)
    Movies findByMovie(String title);

//    List<Movies> findByGenre(String genre);


    @Query(
            value= "select m.id,m.description,m.genre,m.title, m.year \n" +
                    "from movies as m \n" +
                    "where m.year BETWEEN  :yearFrom and :yearTo",
            nativeQuery = true)
    List<Movies> findByRange(int yearFrom, int yearTo);

    @Query(value = "select m.id,m.description,m.genre,m.title,m.year\n" +
            "from movies as m inner join average_rating as avgr\n" +
            "on m.id=avgr.movieid order by avgr.averagerating desc ;",
            nativeQuery = true)
    List<Movies> sortedMovieList();
}
